# things to maybe add
- theorem 6.6 my_fav paper page 15
    - G multilaterial implies superpolynomial growth
    - by theorem 1.11, they mean theorem 1.13
    - G \approx G \times G


# old
- note that G is a p-group
- page 9 of pak and grigor:
    - a = aba

- give other definition of self-similar groups in terms of center of group

- thing that SS-Gs have been able to prove:
    - existence of groups of intermediate growth
    - existence of non-elementary amenable groups
    - infinite finitely generated torsion groups
